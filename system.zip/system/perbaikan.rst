###################
Penggunaan atribut #[\AllowDynamicProperties] di CI3 akan memastikan bahwa aplikasi CI3 Anda dapat berjalan di PHP versi 9. Hal ini karena atribut ini akan mengizinkan penggunaan properti dinamis, yang merupakan fitur baru di PHP versi 9.
###################

Saya pikir cara yang lebih baik adalah menerapkan #[\AllowDynamicProperties]
Lebih pendek dan lebih mudah.
Saya memberi Anda perubahan saya.
Sumber: https://github.com/bcit-ci/CodeIgniter/pull/6193
Sumber: https://stackoverflow.com/questions/75122899/creation-of-dynamic-property-ci-uriconfig-is-deprecated

Pada file: /system/core/URI.php
Tambahkan: #[\AllowDynamicProperties]
Sebelum: class CI_URI {


Pada file: /system/core/Router.php
Tambahkan: #[\AllowDynamicProperties]
Sebelum: class CI_Router {


Pada file: /system/core/Loader.php
Tambahkan: #[\AllowDynamicProperties]
Sebelum: class CI_Loader {


Pada file: /system/core/Controller.php
Tambahkan: #[\AllowDynamicProperties]
Sebelum: class CI_Controller {


Pada file: /system/core/DB_driver.php
Tambahkan: #[\AllowDynamicProperties]
Sebelum: abstract class CI_DB_driver {


***************
Penjelasan
***************


Fungsi dari #[\AllowDynamicProperties] di CI3 adalah untuk mengizinkan penggunaan properti dinamis di kelas tersebut. Properti dinamis adalah properti yang tidak dideklarasikan secara eksplisit di kelas, tetapi dapat ditetapkan secara dinamis menggunakan operator `->`.

Pada PHP versi 8.2, penggunaan properti dinamis di kelas yang tidak menggunakan atribut `#[\AllowDynamicProperties]` akan menghasilkan peringatan (warning). Peringatan ini akan diubah menjadi kesalahan (error) pada PHP versi 9.

Untuk mengatasi peringatan ini, kita dapat menambahkan atribut `#[\AllowDynamicProperties]` di kelas yang menggunakan properti dinamis. Atribut ini akan mengizinkan penggunaan properti dinamis di kelas tersebut tanpa menghasilkan peringatan.

Pada contoh di atas, kelas `MyClass` menggunakan atribut `#[\AllowDynamicProperties]` untuk mengizinkan penggunaan properti dinamis `name`. Properti `name` kemudian dapat ditetapkan secara dinamis menggunakan operator `->`.

Berikut adalah beberapa hal yang perlu diperhatikan saat menggunakan atribut `#[\AllowDynamicProperties]`:

* Atribut ini hanya berlaku untuk kelas yang menggunakan properti dinamis.
* Atribut ini tidak boleh digunakan di kelas yang menggunakan properti statis.
* Atribut ini tidak boleh digunakan di kelas yang menggunakan properti protected atau private.

Demikian penjelasan tentang fungsi dari #[\AllowDynamicProperties] di CI3.



***************
Developer Code
***************
- Harun Rasyid
- m45h4run (Cari di Google)
- Suport `https://bard.google.com/chat/`


